from app.db import Base, engine, SessionLocal
from app.ingestion import ingest_all


def main() -> None:
    print("[DB] Création des tables...")
    Base.metadata.create_all(bind=engine)
    print("[DB] Tables créées.")

    with SessionLocal() as db:
        ingest_all(db)

    print("[DB] Initialisation terminée ✅")


if __name__ == "__main__":
    main()
