const API_URL = "http://127.0.0.1:8000";

async function login() {
    const user = document.getElementById("username").value;
    const pass = document.getElementById("password").value;

    try {
        const res = await fetch(`${API_URL}/auth/login`, {
            method: "POST",
            headers: { "Content-Type": "application/x-www-form-urlencoded" },
            body: new URLSearchParams({ username: user, password: pass })
        });

        if (!res.ok) {
            document.getElementById("login-error").classList.remove("hidden");
            return;
        }

        const data = await res.json();
        localStorage.setItem("token", data.access_token);

        document.getElementById("login-section").classList.add("hidden");
        document.getElementById("zones-section").classList.remove("hidden");

        loadZones();
    } catch (err) {
        console.error("Erreur login():", err);
    }
}


async function loadZones() {
    const token = localStorage.getItem("token");

    const res = await fetch(`${API_URL}/zones`, {
        headers: { "Authorization": "Bearer " + token }
    });

    const zones = await res.json();
    const container = document.getElementById("zones-list");
    container.innerHTML = "";

    zones.forEach(z => {
        container.innerHTML += `
            <div class="zone-card">
                <h3>${z.name}</h3>
                <p>Code postal : ${z.postal_code || "-"}</p>
                <button onclick="loadIndicators(${z.id})">Voir les indicateurs</button>
            </div>
        `;
    });
}

function getQualityBadge(value) {
    if (value < 10) return `<span class="badge badge-green">Bonne</span>`;
    if (value < 20) return `<span class="badge badge-yellow">Moyenne</span>`;
    return `<span class="badge badge-red">Mauvaise</span>`;
}

async function loadIndicators(zoneId) {
    const token = localStorage.getItem("token");

    const res = await fetch(`${API_URL}/indicators?zone_id=${zoneId}`, {
        headers: { "Authorization": "Bearer " + token }
    });

    const data = await res.json();
    const container = document.getElementById("indicator-list");

    if (data.length === 0) {
        container.innerHTML = "<p>Aucun indicateur disponible.</p>";
        return;
    }

    let html = `
    <table>
        <tr>
            <th>Type</th>
            <th>Valeur</th>
            <th>Unité</th>
            <th>Qualité</th>
            <th>Heure</th>
        </tr>
    `;

    data.forEach(ind => {
        html += `
            <tr>
                <td>${ind.type}</td>
                <td>${ind.value}</td>
                <td>${ind.unit || "-"}</td>
                <td>${getQualityBadge(ind.value)}</td>
                <td>${ind.timestamp}</td>
            </tr>
        `;
    });

    html += "</table>";
    container.innerHTML = html;

    document.getElementById("indicators-section").classList.remove("hidden");
}
