from pathlib import Path
from dotenv import load_dotenv
import os

# Dossier racine du projet
BASE_DIR = Path(__file__).resolve().parent.parent

# Charge les variables du .env
load_dotenv(BASE_DIR / ".env")

# URL de la base (SQLite par défaut)
DATABASE_URL = os.getenv("DATABASE_URL", "sqlite:///./ecotrack.db")

OPENAQ_API_KEY = os.getenv("OPENAQ_API_KEY")
