import os
from datetime import datetime
from typing import Optional, Dict, Any, List

import requests
from sqlalchemy.orm import Session

from .config import OPENAQ_API_KEY
from .models import Zone, Source, Indicator
import json


# ----------- Helpers génériques ----------- #

def parse_iso_datetime(value: str) -> datetime:
    if value.endswith("Z"):
        value = value.replace("Z", "+00:00")
    return datetime.fromisoformat(value)


def get_or_create_zone(
    db: Session,
    name: str,
    postal_code: Optional[str] = None,
) -> Zone:
    zone = (
        db.query(Zone)
        .filter(Zone.name == name, Zone.postal_code == postal_code)
        .first()
    )
    if zone:
        return zone

    zone = Zone(name=name, postal_code=postal_code)
    db.add(zone)
    db.commit()
    db.refresh(zone)
    return zone


def get_or_create_source(
    db: Session,
    name: str,
    description: Optional[str] = None,
) -> Source:
    src = db.query(Source).filter(Source.name == name).first()
    if src:
        return src

    src = Source(name=name, description=description)
    db.add(src)
    db.commit()
    db.refresh(src)
    return src


# ----------- Source 1 : Open-Meteo Air Quality ----------- #

OPEN_METEO_AIR_QUALITY_URL = "https://air-quality-api.open-meteo.com/v1/air-quality"


def ingest_open_meteo_air_quality(
    db: Session,
    *,
    zone_name: str,
    postal_code: Optional[str],
    latitude: float,
    longitude: float,
) -> None:
    """
    Récupère des données de qualité de l'air via Open-Meteo et
    les insère dans la table indicators.
    """
    print(f"[Open-Meteo] Ingestion pour {zone_name}...")

    params = {
        "latitude": latitude,
        "longitude": longitude,
        "hourly": "pm10,pm2_5,carbon_monoxide",
        "timezone": "Europe/Paris",
        "past_days": 1,      # tu peux ajuster
        "forecast_days": 0,  # pas besoin de forecast pour init
    }

    response = requests.get(OPEN_METEO_AIR_QUALITY_URL, params=params, timeout=15)
    response.raise_for_status()
    data = response.json()

    hourly = data.get("hourly") or {}
    times: List[str] = hourly.get("time") or []

    variables = {
        "pm10": "µg/m³",
        "pm2_5": "µg/m³",
        "carbon_monoxide": "mg/m³",  # approximation
    }

    zone = get_or_create_zone(db, name=zone_name, postal_code=postal_code)
    source = get_or_create_source(
        db,
        name="open-meteo-air-quality",
        description="Open-Meteo Air Quality hourly forecast API",
    )

    for idx, t in enumerate(times):
        timestamp = parse_iso_datetime(t)
        for var_name, unit in variables.items():
            values = hourly.get(var_name)
            if not values:
                continue

            value = values[idx]
            if value is None:
                continue

            indicator = Indicator(
                source_id=source.id,
                type=var_name,
                value=float(value),
                unit=unit,
                timestamp=timestamp,
                zone_id=zone.id,
                extra={
                    "latitude": latitude,
                    "longitude": longitude,
                    "api": "open-meteo",
                },
            )
            db.add(indicator)

    db.commit()
    print(f"[Open-Meteo] Insertion terminée ({len(times)} pas de temps).")


# ----------- Source 2 : OpenAQ Latest par location ----------- #

OPENAQ_LOCATION_LATEST_URL = "https://api.openaq.org/v3/locations/{location_id}/latest"


def ingest_openaq_latest_for_location(
    db: Session,
    *,
    location_id: int,
    city: str,
    postal_code: str | None
):
    url = f"https://api.openaq.org/v3/locations/{location_id}/latest"
    headers = {"X-API-Key": OPENAQ_API_KEY}

    print(f"[OpenAQ] Fetch {location_id} for {city}...")

    r = requests.get(url, headers=headers, timeout=15)
    if r.status_code != 200:
        print("[OpenAQ] ERROR", r.text)
        return

    data = r.json()

    results = data.get("results", [])
    if not results:
        print("[OpenAQ] No results.")
        return

    # Create zone + source
    zone = get_or_create_zone(db, city, postal_code)
    source = get_or_create_source(
        db,
        name="openaq-latest",
        description="OpenAQ latest measurements (new API format)"
    )

    count = 0

    for item in results:
        utc_time = item.get("datetime", {}).get("utc")
        if not utc_time:
            continue

        timestamp = parse_iso_datetime(utc_time)

        indicator = Indicator(
            source_id=source.id,
            type=f"sensor_{item.get('sensorsId')}",
            value=item.get("value"),
            unit=None,  # New format doesn’t provide units
            timestamp=timestamp,
            zone_id=zone.id,
            extra={
                "latitude": item.get("coordinates", {}).get("latitude"),
                "longitude": item.get("coordinates", {}).get("longitude"),
                "sensor_id": item.get("sensorsId"),
                "api": "openaq",
            }
        )

        db.add(indicator)
        count += 1

    db.commit()
    print(f"[OpenAQ] Stored {count} measurements.")


# ----------- Orchestrateur ----------- #

def ingest_all(db: Session):
    ingest_open_meteo_air_quality(
        db,
        zone_name="Paris",
        postal_code="75000",
        latitude=48.8566,
        longitude=2.3522,
    )

    ingest_openaq_latest_for_location(
        db,
        location_id=3819,
        city="Albuquerque",
        postal_code="87101",
    )

    ingest_open_meteo_air_quality(
        db,
        zone_name="Albuquerque",
        postal_code="87101",
        latitude=35.0844,
        longitude=-106.6504,
    )

    ingest_openaq_latest_for_location(
        db,
        location_id=15395,  # Paris
        city="Paris",
        postal_code="75000",
    )