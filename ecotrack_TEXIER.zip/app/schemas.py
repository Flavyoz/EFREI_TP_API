
from datetime import datetime
from pydantic import BaseModel
from typing import Optional, Any


# ----- Zone -----
class ZoneBase(BaseModel):
    name: str
    postal_code: Optional[str]


class ZoneCreate(ZoneBase):
    pass


class ZoneOut(ZoneBase):
    id: int

    class Config:
        orm_mode = True


# ----- Source -----
class SourceBase(BaseModel):
    name: str
    description: Optional[str]


class SourceCreate(SourceBase):
    pass


class SourceOut(SourceBase):
    id: int

    class Config:
        orm_mode = True


# ----- Indicator -----
class IndicatorBase(BaseModel):
    type: str
    value: float
    unit: Optional[str]
    timestamp: datetime
    zone_id: int
    source_id: int
    extra: Optional[Any]


class IndicatorCreate(IndicatorBase):
    pass


class IndicatorOut(IndicatorBase):
    id: int

    class Config:
        orm_mode = True


# ----- User -----
class UserBase(BaseModel):
    username: str


class UserCreate(UserBase):
    password: str


class UserOut(UserBase):
    id: int
    is_admin: bool

    class Config:
        orm_mode = True


class Token(BaseModel):
    access_token: str
    token_type: str
