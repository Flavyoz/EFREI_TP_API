from fastapi import FastAPI
from app.db import SessionLocal
from app import models

from app.routers import zones, sources, indicators, stats, auth
from fastapi.middleware.cors import CORSMiddleware

app = FastAPI(
    title="EcoTrack API",
    description="API de récupération et de consultation des données environnementales",
    version="1.0.0"
)

app.include_router(zones.router)
app.include_router(sources.router)
app.include_router(indicators.router)
app.include_router(stats.router)
app.include_router(auth.router)

@app.get("/")
def root():
    return {"status": "EcoTrack API ready 🚀"}


origins = [
    "http://localhost:8001",
    "http://127.0.0.1:8001"
]

app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)
