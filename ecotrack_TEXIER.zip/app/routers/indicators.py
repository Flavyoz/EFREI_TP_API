
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from app.db import SessionLocal
from app.models import Indicator
from app.schemas import IndicatorCreate, IndicatorOut


router = APIRouter(prefix="/indicators", tags=["Indicators"])


def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


# ---- GET ALL ----
@router.get("/", response_model=list[IndicatorOut])
def read_indicators(db: Session = Depends(get_db)):
    return db.query(Indicator).all()


# ---- GET BY ID ----
@router.get("/{indicator_id}", response_model=IndicatorOut)
def read_indicator(indicator_id: int, db: Session = Depends(get_db)):
    indicator = (
        db.query(Indicator)
        .filter(Indicator.id == indicator_id)
        .first()
    )
    if not indicator:
        raise HTTPException(status_code=404, detail="Indicator not found")
    return indicator


# ---- CREATE ----
@router.post("/", response_model=IndicatorOut)
def create_indicator(data: IndicatorCreate, db: Session = Depends(get_db)):
    new_indicator = Indicator(
        type=data.type,
        value=data.value,
        unit=data.unit,
        timestamp=data.timestamp,
        zone_id=data.zone_id,
        source_id=data.source_id,
        extra=data.extra,
    )
    db.add(new_indicator)
    db.commit()
    db.refresh(new_indicator)
    return new_indicator


# ---- DELETE ----
@router.delete("/{indicator_id}")
def delete_indicator(indicator_id: int, db: Session = Depends(get_db)):
    indicator = (
        db.query(Indicator)
        .filter(Indicator.id == indicator_id)
        .first()
    )
    if not indicator:
        raise HTTPException(status_code=404, detail="Indicator not found")

    db.delete(indicator)
    db.commit()
    return {"detail": "Indicator deleted successfully"}
