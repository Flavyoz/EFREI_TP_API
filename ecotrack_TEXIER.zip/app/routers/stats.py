from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from sqlalchemy import func

from app.db import SessionLocal
from app.models import Indicator, Zone


router = APIRouter(prefix="/stats", tags=["Statistics"])


def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


# ------------------------------------------------
# 1. Stats globales par type d’indicateur (pm10, pm2_5, etc.)
# ------------------------------------------------
@router.get("/indicator/{indicator_type}")
def stats_by_indicator_type(indicator_type: str, db: Session = Depends(get_db)):
    q = (
        db.query(
            func.min(Indicator.value).label("min"),
            func.avg(Indicator.value).label("avg"),
            func.max(Indicator.value).label("max"),
            func.count(Indicator.id).label("count"),
        )
        .filter(Indicator.type == indicator_type)
        .first()
    )

    if q.count == 0:
        raise HTTPException(status_code=404, detail="No data for this indicator type")

    return {
        "indicator_type": indicator_type,
        "min": q.min,
        "avg": q.avg,
        "max": q.max,
        "count": q.count,
    }


# ------------------------------------------------
# 2. Stats pour une zone (tous indicateurs confondus)
# ------------------------------------------------
@router.get("/zone/{zone_id}")
def stats_by_zone(zone_id: int, db: Session = Depends(get_db)):
    zone = db.query(Zone).filter(Zone.id == zone_id).first()
    if not zone:
        raise HTTPException(status_code=404, detail="Zone not found")

    q = (
        db.query(
            Indicator.type,
            func.avg(Indicator.value).label("avg"),
            func.min(Indicator.value).label("min"),
            func.max(Indicator.value).label("max"),
            func.count(Indicator.id).label("count"),
        )
        .filter(Indicator.zone_id == zone_id)
        .group_by(Indicator.type)
        .all()
    )

    return {
        "zone": zone.name,
        "indicators": [
            {
                "type": row.type,
                "min": row.min,
                "avg": row.avg,
                "max": row.max,
                "count": row.count,
            }
            for row in q
        ],
    }


# ------------------------------------------------
# 3. Stats zone + type (ex: pm10 à Paris)
# ------------------------------------------------
@router.get("/zone/{zone_id}/{indicator_type}")
def stats_zone_and_type(zone_id: int, indicator_type: str, db: Session = Depends(get_db)):
    q = (
        db.query(
            func.min(Indicator.value).label("min"),
            func.avg(Indicator.value).label("avg"),
            func.max(Indicator.value).label("max"),
            func.count(Indicator.id).label("count"),
        )
        .filter(Indicator.zone_id == zone_id, Indicator.type == indicator_type)
        .first()
    )

    if q.count == 0:
        raise HTTPException(status_code=404, detail="No data for this zone / indicator")

    return {
        "zone_id": zone_id,
        "indicator_type": indicator_type,
        "min": q.min,
        "avg": q.avg,
        "max": q.max,
        "count": q.count,
    }


# ------------------------------------------------
# 4. Stats avec intervalle temporel
# ------------------------------------------------
@router.get("/range")
def stats_by_date_range(type: str, start: str, end: str, db: Session = Depends(get_db)):
    """
    type = type d’indicateur (ex : 'pm10')
    start/end = timestamps ISO (ex: 2025-11-20T00:00:00)
    """
    q = (
        db.query(
            func.min(Indicator.value).label("min"),
            func.avg(Indicator.value).label("avg"),
            func.max(Indicator.value).label("max"),
            func.count(Indicator.id).label("count"),
        )
        .filter(Indicator.type == type)
        .filter(Indicator.timestamp >= start)
        .filter(Indicator.timestamp <= end)
        .first()
    )

    return {
        "indicator_type": type,
        "start": start,
        "end": end,
        "min": q.min,
        "avg": q.avg,
        "max": q.max,
        "count": q.count,
    }


# ------------------------------------------------
# 5. Endpoint "top" : zones les plus polluées pour un indicateur
# ------------------------------------------------
@router.get("/top/{indicator_type}")
def top_zones(indicator_type: str, limit: int = 5, db: Session = Depends(get_db)):
    q = (
        db.query(
            Zone.name,
            func.avg(Indicator.value).label("avg"),
        )
        .join(Zone, Zone.id == Indicator.zone_id)
        .filter(Indicator.type == indicator_type)
        .group_by(Zone.id)
        .order_by(func.avg(Indicator.value).desc())
        .limit(limit)
        .all()
    )

    return [{"zone": row.name, "avg": row.avg} for row in q]
