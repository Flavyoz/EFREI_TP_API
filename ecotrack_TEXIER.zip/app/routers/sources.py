from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from app.db import SessionLocal
from app.models import Source
from app.schemas import SourceCreate, SourceOut


router = APIRouter(prefix="/sources", tags=["Sources"])


def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


# ---- GET ALL ----
@router.get("/", response_model=list[SourceOut])
def read_sources(db: Session = Depends(get_db)):
    return db.query(Source).all()


# ---- GET BY ID ----
@router.get("/{source_id}", response_model=SourceOut)
def read_source(source_id: int, db: Session = Depends(get_db)):
    source = db.query(Source).filter(Source.id == source_id).first()
    if not source:
        raise HTTPException(status_code=404, detail="Source not found")
    return source


# ---- CREATE ----
@router.post("/", response_model=SourceOut)
def create_source(src: SourceCreate, db: Session = Depends(get_db)):
    new_source = Source(name=src.name, description=src.description)
    db.add(new_source)
    db.commit()
    db.refresh(new_source)
    return new_source


# ---- DELETE ----
@router.delete("/{source_id}")
def delete_source(source_id: int, db: Session = Depends(get_db)):
    source = db.query(Source).filter(Source.id == source_id).first()
    if not source:
        raise HTTPException(status_code=404, detail="Source not found")

    db.delete(source)
    db.commit()
    return {"detail": "Source deleted successfully"}
