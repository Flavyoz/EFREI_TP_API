
from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from app.db import SessionLocal
from app.models import Zone
from app.schemas import ZoneCreate, ZoneOut
from app.dependencies import require_admin


router = APIRouter(prefix="/zones", tags=["Zones"])


def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


@router.get("/", response_model=list[ZoneOut])
def get_all_zones(db: Session = Depends(get_db)):
    return db.query(Zone).all()


@router.post("/", response_model=ZoneOut, dependencies=[Depends(require_admin)])
def create_zone(zone: ZoneCreate, db: Session = Depends(get_db)):
    new_zone = Zone(name=zone.name, postal_code=zone.postal_code)
    db.add(new_zone)
    db.commit()
    db.refresh(new_zone)
    return new_zone
